//
//  AlertaView.swift
//  Swift200_Day2_TextField
//
//  Created by Swift on 19/08/17.
//  Copyright © 2017 quaddro. All rights reserved.
//

import UIKit

class AlertaView : UIView {
    
    init(frame: CGRect, texto:String) {
        super.init(frame: frame)
        
        // fundo escuro
        self.backgroundColor = UIColor.black.withAlphaComponent(0.8)
        self.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    }
    
    // Evitando uso errado da classe
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
}
