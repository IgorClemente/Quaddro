//
//  ViewController.swift
//  Swift300_Day3_AccelerometerLog
//
//  Created by Nilo on 18/11/17.
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit

/*
 
 👨🏻‍🍳 Como obter dados do accelerometer
 
 1) Incluir o CoreMotion
 2) Criar let do gestor
 3) Criar função que receberá os dados
 4) Pedir updates para o gestor
 5) Opcional: normalizar os dados
 
 */

class ViewController: UIViewController {
    
    @IBOutlet weak var uiLog:UITextView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}

