//
//  ViewController.swift
//  Swift300_Day3_PedometerLog
//
//  Created by Nilo on 18/11/17.
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit
/*
 
 👨🏻‍🍳 Como obter dados do pedometer
 
    1) Adicionar texto de permissão no info.plist
    2) Incluir o CoreMotion
    3) Criar let do gestor
    4) Criar função que receberá os dados
    5) Pedir updates para o gestor
 
*/

class ViewController: UIViewController {

    @IBOutlet weak var uiLogView:UITextView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

}

