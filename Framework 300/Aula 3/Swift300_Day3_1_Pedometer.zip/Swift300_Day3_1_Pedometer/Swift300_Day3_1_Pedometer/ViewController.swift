//
//  ViewController.swift
//  Swift300_Day3_1_Pedometer
//
//  Created by Nilo on 17/11/17.
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var uiProgress:ProgressView?
    @IBOutlet weak var uiEgg:RemelexoView?
    @IBOutlet weak var uiEggIcon:UILabel?
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
    }

    
    
    // Tap no ovo
    @IBAction func tapOnEgg(){
        self.uiEggIcon?.text = "🥚"
    }
    
    // Chame essa função para chocar
    func hatch(){
        let animals = Array("🐣🐥🦉🦆🐢🐍🦎".characters)
        let choosen = animals[ Int(arc4random()+1) % animals.count]
        self.uiEggIcon?.text = "\(choosen)"
    }
    
    // Chame essa função para chacoalhar o ovo
    func shakeIt(){
        self.uiEgg?.animar()
    }
    
}

