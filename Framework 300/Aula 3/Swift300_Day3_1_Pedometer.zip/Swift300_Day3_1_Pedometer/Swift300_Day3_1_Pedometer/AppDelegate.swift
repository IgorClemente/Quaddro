//
//  AppDelegate.swift
//  Swift300_Day3_1_Pedometer
//
//  Created by Nilo on 17/11/17.
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
}

