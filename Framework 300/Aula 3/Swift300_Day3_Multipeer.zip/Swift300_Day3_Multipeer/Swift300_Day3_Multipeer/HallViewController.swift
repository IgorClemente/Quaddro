//
//  HallViewController.swift
//  Swift300_Day3_Multipeer
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit

class HallViewController: UIViewController {

    @IBOutlet weak var uiName: UITextField?
    
    @IBAction func tapCreate() {
        
    }
    
    @IBAction func tapJoin() {
        
    }
}
