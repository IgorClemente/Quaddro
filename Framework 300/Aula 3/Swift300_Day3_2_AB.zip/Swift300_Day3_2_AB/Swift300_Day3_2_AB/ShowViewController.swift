//
//  ShowViewController.swift
//  Swift300_Day3_2_AB
//
//  Created by Nilo on 18/11/17.
//  Copyright © 2017 Nilo. All rights reserved.
//

import UIKit

/*
 
 👩🏻‍🍳 Implementando o AB
 1) Adicione o gestor, função de update e normalize os dados
 2) O que acontece em cada eixo? O que acontece quando virado para baixo?
 3) Implemente a vibração quando virado para baixo
 4) O que acontece quando viro de um lado ou de outro?
 5) Implemente a troca de texto dependendo do movimento
 
 💪🏻 Força!
 
 */

class ShowViewController: UIViewController {

    enum ChosenOne : String {
        case A, B, secret
    }
    
    @IBOutlet weak var uiResponse:UILabel?
    var chosen:ChosenOne = .secret
    
    // Dica:
    
    // indica se o device já está virado para baixo
    // se 'pronto' = true já podemos monitorar o lado que vira
    // ou colocar o texto, dependendo de 'chosen'
    var pronto = false
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Na tela anterior foi escolhido:\(chosen.rawValue)")
    }
    
    @IBAction func tapPlayAgain(){
        dismiss(animated: true, completion: nil)
    }

}
