//: Comment 
/*
 
Comentario Varias Linhas

 */

print("OI") //Comentario fim de linha
/*Comeco de linha*/ print("Ola")

//Comentario com Markup :




